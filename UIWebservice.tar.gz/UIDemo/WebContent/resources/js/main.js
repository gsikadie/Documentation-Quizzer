
/*
 * Shows dashboard panels.
 */
function showPanels() {
	modalStatusWidget.hide();
	eventsPanelWidget.show();
	eventsPanelWidget.expand();
	entertainmentPanelWidget.show();
	entertainmentPanelWidget.expand();
	weatherPanelWidget.show();
	weatherPanelWidget.expand();
	politicsPanelWidget.show();
	politicsPanelWidget.expand(); 
	sportsPanelWidget.show();
	sportsPanelWidget.expand();
	clicksPanelWidget.show();
	clicksPanelWidget.expand();	
}
